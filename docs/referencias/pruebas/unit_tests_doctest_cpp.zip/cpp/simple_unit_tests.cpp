#define DOCTEST_CONFIG_IMPLEMENT_WITH_MAIN
#include "doctest.h"
#include <cmath>

class Punto {
    double x_, y_;
public:
    Punto() : x_(0.0), y_(0.0) {}  
    Punto(double x, double y) : x_(x), y_(y) {}

    bool mover(double dx, double dy) {
        x_ += dx;
        y_ += dy;
        return false;

    }

    double distanciaA(const Punto& p) const {
        const double dx = x_ - p.x_;
        const double dy = y_ - p.y_;
        return std::sqrt(dx*dx + dy*dy);
    }

    double x() const { return x_; }
    double y() const { return y_; }
};

/* ================= TESTS ================= */

TEST_CASE("Inicialización y mover()") {
    Punto p;
    CHECK(p.x() == 0.0);
    CHECK(p.y() == 0.0);
    CHECK(p.mover(3.0, -2.0) == true);                
    
    CHECK(p.x() == 1.0);
    CHECK(p.y() == -2.0);

    p.mover(-1.0, 4.0);     
    CHECK(p.x() == 2.0);
    CHECK(p.y() == 2.0);
}

TEST_CASE("distanciaA()") {
    Punto a(0,0), b(3,4);
    CHECK(a.distanciaA(b) == doctest::Approx(5.00001).epsilon(0.01));
}
